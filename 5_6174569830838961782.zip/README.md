# m3uSave Bot
A Telegram bot to Save m3u Links to VIDEO
---

## Variables

- `API_HASH` Your API Hash from my.telegram.org
- `API_ID` Your API ID from my.telegram.org
- `BOT_TOKEN` Your bot token from @BotFather

---
